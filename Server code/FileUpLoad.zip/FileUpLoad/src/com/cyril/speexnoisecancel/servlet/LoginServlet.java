package com.cyril.speexnoisecancel.servlet;

import com.cyril.speexnoisecancel.util.DBHelper;
import com.mysql.jdbc.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by linxu on 2017/11/30.
 */
//@WebServlet(name = "LoginServlet")
public class LoginServlet extends HttpServlet {
    String username = "";
    String password = "";
    Connection connection;

    public LoginServlet() {
        try {
            connection = DBHelper.getConntion();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        username = request.getParameter("username");
        password = request.getParameter("password");
        if (username != null && !username.equals("")&&password != null && !password.equals("")) {
            if (isExistUser(username,password)){
                response.getWriter().print(true);
                System.out.println(123);
            }
        }else {
            System.out.println(321);
            response.getWriter().print(false);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    private boolean isExistUser(String username, String password) {
        try {
            String url = "select * from user where username = ? and password=?";

            PreparedStatement pstm = (PreparedStatement) connection.prepareStatement(url);
            pstm.setString(1,username);
            pstm.setString(2,password);
            ResultSet rs = pstm.executeQuery();
            rs.next();
            if(rs.next()) {
                int count = rs.getInt(1);
                if (count > 0) {
                    System.out.println("信息已存在！");
                    return true;
                }
            } else{
                System.out.println("信息不存在！");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
