package com.cyril.speexnoisecancel.util;

import com.mysql.jdbc.PreparedStatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by LinXu on 2016/12/9.
 */
public class DBHelper {

    private static final String url = "jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=UTF-8";
    private static final String name = "com.mysql.jdbc.Driver";
    private static final String user = "root";
    private static final String password = "";

    private static Connection conn = null;

    /**
     * 数据库连接
     */
    //静态代码块加载驱动
    static {
        try {
            Class.forName(name);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static Connection getConntion() throws SQLException {
        if (conn == null) {
            conn = DriverManager.getConnection(url, user, password);
            return conn;
        }
        return conn;
    }

//    public static void main(String args[]) {
//        try {
//            Connection conn = DBHelper.getConntion();
//            if (conn != null) {
//                System.out.println("数据库连接正常");
//                isExistUser("linxu","123");
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
    private static boolean isExistUser(String username, String password) {
        try {
            String url = "select * from user where username = ? and password=?";

            PreparedStatement pstm = (PreparedStatement) getConntion().prepareStatement(url);
            pstm.setString(1,username);
            pstm.setString(2,password);
            ResultSet rs = pstm.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            if (count > 0) {
                System.out.println("注册信息已存在！");
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
